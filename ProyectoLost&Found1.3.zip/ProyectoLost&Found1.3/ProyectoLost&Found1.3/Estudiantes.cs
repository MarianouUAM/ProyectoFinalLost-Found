﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoLost_Found1._3
{
    public partial class Estudiantes : Form
    {
        public Estudiantes()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //txtFecha.Text = DateTime.Now.ToString("yyyy-MM-dd"); // Solo la fecha
            //txtHora.Text = DateTime.Now.ToString("HH:mm:ss");   // Solo la hora
        }

        private void Estudiantes_Load(object sender, EventArgs e)
        {
            txtFecha.Text = DateTime.Now.ToString("yyyy-MM-dd"); // Solo la fecha
            txtHora.Text = DateTime.Now.ToString("HH:mm:ss");   // Solo la hora
        }

        private void boton_personalizado1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
