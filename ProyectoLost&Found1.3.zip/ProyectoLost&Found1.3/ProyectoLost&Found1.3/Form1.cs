﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoLost_Found1._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnInicioSesion_Click(object sender, EventArgs e)
        {
            string usuario, contraseña;

            usuario = txtUsuario.Text;
            contraseña = txtContraseña.Text;

           if( usuario == "Administrador" && contraseña == "ContraAdmi")
            {
                Administradores principal = new Administradores();
                principal.Show();
                this.Hide();
            }


            if (usuario == "Estudiante" && contraseña == "ContraEstudiante")
            {
                Estudiantes principal = new Estudiantes();
                principal.Show();
                this.Hide();
            }

        }


    }
}
