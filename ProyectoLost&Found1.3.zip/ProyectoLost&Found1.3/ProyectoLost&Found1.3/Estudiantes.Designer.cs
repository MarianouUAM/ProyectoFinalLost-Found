﻿namespace ProyectoLost_Found1._3
{
    partial class Estudiantes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Estudiantes));
            this.lblTipoReporte = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbkCaracteristicas = new System.Windows.Forms.Label();
            this.lblCategoria = new System.Windows.Forms.Label();
            this.lblHora = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.lblLugar = new System.Windows.Forms.Label();
            this.txtCarateristicas = new System.Windows.Forms.TextBox();
            this.txtLugar = new System.Windows.Forms.TextBox();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.cmbTipoReporte = new System.Windows.Forms.ComboBox();
            this.cmbCategoria = new System.Windows.Forms.ComboBox();
            this.txtFecha = new System.Windows.Forms.TextBox();
            this.boton_personalizado1 = new ProyectoLost_Found.Boton_personalizado();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTipoReporte
            // 
            this.lblTipoReporte.AutoSize = true;
            this.lblTipoReporte.BackColor = System.Drawing.Color.White;
            this.lblTipoReporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoReporte.Location = new System.Drawing.Point(178, 78);
            this.lblTipoReporte.Name = "lblTipoReporte";
            this.lblTipoReporte.Size = new System.Drawing.Size(116, 20);
            this.lblTipoReporte.TabIndex = 1;
            this.lblTipoReporte.Text = "Tipo de reporte";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(829, 811);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lbkCaracteristicas
            // 
            this.lbkCaracteristicas.AutoSize = true;
            this.lbkCaracteristicas.BackColor = System.Drawing.Color.White;
            this.lbkCaracteristicas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbkCaracteristicas.Location = new System.Drawing.Point(178, 179);
            this.lbkCaracteristicas.Name = "lbkCaracteristicas";
            this.lbkCaracteristicas.Size = new System.Drawing.Size(114, 20);
            this.lbkCaracteristicas.TabIndex = 2;
            this.lbkCaracteristicas.Text = "Caracteristicas";
            // 
            // lblCategoria
            // 
            this.lblCategoria.AutoSize = true;
            this.lblCategoria.BackColor = System.Drawing.Color.White;
            this.lblCategoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoria.Location = new System.Drawing.Point(178, 275);
            this.lblCategoria.Name = "lblCategoria";
            this.lblCategoria.Size = new System.Drawing.Size(78, 20);
            this.lblCategoria.TabIndex = 3;
            this.lblCategoria.Text = "Categoria";
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.BackColor = System.Drawing.Color.White;
            this.lblHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.Location = new System.Drawing.Point(184, 376);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(44, 20);
            this.lblHora.TabIndex = 4;
            this.lblHora.Text = "Hora";
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.BackColor = System.Drawing.Color.White;
            this.lblFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.Location = new System.Drawing.Point(184, 476);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(54, 20);
            this.lblFecha.TabIndex = 5;
            this.lblFecha.Text = "Fecha";
            // 
            // lblLugar
            // 
            this.lblLugar.AutoSize = true;
            this.lblLugar.BackColor = System.Drawing.Color.White;
            this.lblLugar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLugar.Location = new System.Drawing.Point(184, 564);
            this.lblLugar.Name = "lblLugar";
            this.lblLugar.Size = new System.Drawing.Size(50, 20);
            this.lblLugar.TabIndex = 6;
            this.lblLugar.Text = "Lugar";
            // 
            // txtCarateristicas
            // 
            this.txtCarateristicas.AllowDrop = true;
            this.txtCarateristicas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCarateristicas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCarateristicas.Location = new System.Drawing.Point(182, 214);
            this.txtCarateristicas.Name = "txtCarateristicas";
            this.txtCarateristicas.Size = new System.Drawing.Size(424, 19);
            this.txtCarateristicas.TabIndex = 7;
            // 
            // txtLugar
            // 
            this.txtLugar.AllowDrop = true;
            this.txtLugar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLugar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLugar.Location = new System.Drawing.Point(176, 599);
            this.txtLugar.Name = "txtLugar";
            this.txtLugar.Size = new System.Drawing.Size(424, 19);
            this.txtLugar.TabIndex = 8;
            // 
            // txtHora
            // 
            this.txtHora.AllowDrop = true;
            this.txtHora.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHora.Location = new System.Drawing.Point(182, 412);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(424, 19);
            this.txtHora.TabIndex = 9;
            // 
            // cmbTipoReporte
            // 
            this.cmbTipoReporte.AllowDrop = true;
            this.cmbTipoReporte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTipoReporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTipoReporte.FormattingEnabled = true;
            this.cmbTipoReporte.Items.AddRange(new object[] {
            " Reporte de objeto perdido",
            "Reporte de objeto encontrado"});
            this.cmbTipoReporte.Location = new System.Drawing.Point(182, 114);
            this.cmbTipoReporte.Name = "cmbTipoReporte";
            this.cmbTipoReporte.Size = new System.Drawing.Size(207, 28);
            this.cmbTipoReporte.TabIndex = 10;
            // 
            // cmbCategoria
            // 
            this.cmbCategoria.AllowDrop = true;
            this.cmbCategoria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCategoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCategoria.FormattingEnabled = true;
            this.cmbCategoria.Items.AddRange(new object[] {
            "Academico\t",
            "Personal\t",
            "Tecnologico"});
            this.cmbCategoria.Location = new System.Drawing.Point(176, 307);
            this.cmbCategoria.Name = "cmbCategoria";
            this.cmbCategoria.Size = new System.Drawing.Size(207, 28);
            this.cmbCategoria.TabIndex = 11;
            // 
            // txtFecha
            // 
            this.txtFecha.AllowDrop = true;
            this.txtFecha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFecha.Location = new System.Drawing.Point(182, 511);
            this.txtFecha.Name = "txtFecha";
            this.txtFecha.Size = new System.Drawing.Size(424, 19);
            this.txtFecha.TabIndex = 12;
            // 
            // boton_personalizado1
            // 
            this.boton_personalizado1.BackColor = System.Drawing.Color.MediumBlue;
            this.boton_personalizado1.BackgroundColor = System.Drawing.Color.MediumBlue;
            this.boton_personalizado1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.boton_personalizado1.BorderRadius = 40;
            this.boton_personalizado1.BorderSize = 0;
            this.boton_personalizado1.FlatAppearance.BorderSize = 0;
            this.boton_personalizado1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_personalizado1.ForeColor = System.Drawing.Color.White;
            this.boton_personalizado1.Location = new System.Drawing.Point(609, 712);
            this.boton_personalizado1.Name = "boton_personalizado1";
            this.boton_personalizado1.Size = new System.Drawing.Size(179, 63);
            this.boton_personalizado1.TabIndex = 13;
            this.boton_personalizado1.Text = "boton_personalizado1";
            this.boton_personalizado1.TextColor = System.Drawing.Color.White;
            this.boton_personalizado1.UseVisualStyleBackColor = false;
            this.boton_personalizado1.Click += new System.EventHandler(this.boton_personalizado1_Click);
            // 
            // Estudiantes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 797);
            this.Controls.Add(this.boton_personalizado1);
            this.Controls.Add(this.txtFecha);
            this.Controls.Add(this.cmbCategoria);
            this.Controls.Add(this.cmbTipoReporte);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.txtLugar);
            this.Controls.Add(this.txtCarateristicas);
            this.Controls.Add(this.lblLugar);
            this.Controls.Add(this.lblFecha);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.lblCategoria);
            this.Controls.Add(this.lbkCaracteristicas);
            this.Controls.Add(this.lblTipoReporte);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Estudiantes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Estudiantes";
            this.Load += new System.EventHandler(this.Estudiantes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTipoReporte;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbkCaracteristicas;
        private System.Windows.Forms.Label lblCategoria;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label lblLugar;
        private System.Windows.Forms.TextBox txtCarateristicas;
        private System.Windows.Forms.TextBox txtLugar;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.ComboBox cmbTipoReporte;
        private System.Windows.Forms.ComboBox cmbCategoria;
        private System.Windows.Forms.TextBox txtFecha;
        private ProyectoLost_Found.Boton_personalizado boton_personalizado1;
    }
}